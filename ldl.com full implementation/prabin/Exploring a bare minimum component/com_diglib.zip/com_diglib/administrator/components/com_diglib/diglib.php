<?php
defined( '_JEXEC' ) or die;

echo "Libra Digital Library Backend";