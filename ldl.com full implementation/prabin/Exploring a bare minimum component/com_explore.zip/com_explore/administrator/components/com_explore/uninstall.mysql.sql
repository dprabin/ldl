DROP TABLE `#__explore_activities`;
DROP TABLE `#__explore_tours`;
DROP TABLE `#__explore_favorites`;