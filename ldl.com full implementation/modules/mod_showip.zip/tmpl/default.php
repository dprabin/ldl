<?php defined( '_JEXEC' ) or die; ?>

<div id="ip-address">
	<?php if ($params->get('message')): ?>
		<?php echo $params->get('message'); ?>
	<?php endif ?>
	<?php echo $_SERVER['REMOTE_ADDR']; ?>
</div>
